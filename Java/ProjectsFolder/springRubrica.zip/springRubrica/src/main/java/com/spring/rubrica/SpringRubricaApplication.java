package com.spring.rubrica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRubricaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRubricaApplication.class, args);
	}

}
