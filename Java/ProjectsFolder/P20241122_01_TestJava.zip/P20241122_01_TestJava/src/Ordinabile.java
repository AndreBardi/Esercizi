import java.util.LinkedList;

public interface Ordinabile {
	
    LinkedList<Prodotto> sortByPrice(LinkedList<Prodotto> prodotti);
}
